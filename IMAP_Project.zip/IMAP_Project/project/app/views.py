from django.shortcuts import render,HttpResponse,redirect
from django.http import HttpResponseRedirect
from django.urls import reverse
from app.models import Register
# Create your views here.
def homepage(request):
    return render(request,'Homepage.html')

def register(request):
    if request.method == "POST":
        name = request.POST.get('name')
        address = request.POST.get('address')
        contact = request.POST.get('contact')
        email = request.POST.get('email')
        register = Register(name=name, address=address, contact=contact,email=email)
        register.save()
        # return HttpResponseRedirect(reverse('Questions.html'))
    return render(request,'register.html')

def questions(request):
    return render(request,'Questions.html')

def result(request):
    total_score = 0  
    return render(request, 'result.html', {'total_score': total_score})

def login(request):
    return render(request, 'Login_Page.html')

def about(request):
    return render(request, 'about.html')
