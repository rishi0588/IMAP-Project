from django.contrib import admin

# Register your models here.
from app.models import Register
admin.site.register(Register)